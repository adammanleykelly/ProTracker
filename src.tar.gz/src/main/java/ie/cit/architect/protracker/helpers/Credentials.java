package ie.cit.architect.protracker.helpers;

/**
 * Created by brian on 02/04/17.
 */
public final class Credentials
{
    // mongodb
    public static final String DB_MONGO_USER = "dbuser";
    public static final String DB_MONGO_PASS = "bossdog12";

    public static final String DB_MONGO_IP = "ec2-54-202-69-181.us-west-2.compute.amazonaws.com";

//    public static final String DB_MONGO_IP = "ec2-54-246-248-226.eu-west-1.compute.amazonaws.com";


    // mysql
    public static final String DB_SQL_USER = "brian";
    public static final String DB_SQL_PASS = "topdog12";
    public static final String DB_SQL_IP = "82.118.226.76";
    public static final String DB_SQL_PORT = "3306";

    // generic
    public static final String DB_NAME = "protracker";
}
