package ie.cit.architect.protracker.controller;

/**
 * Created by brian on 13/03/17.
 */
public enum PersistenceMode {
    MONGODB, MYSQL;
}
